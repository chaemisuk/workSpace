/*
	Header Stuck
*/
(function($){
	var subpageHeaderBg = $(".subpage-header__bg");

	if(!subpageHeaderBg.length) return;

	scrollSubpage();
	$(window).resize(function(){
		scrollSubpage();
	});

	function scrollSubpage(){
		if (window.innerWidth > 791) {
			$(window).on('scroll', function(){
				var	yPos = +($(window).scrollTop() / 4),
					coords = 'center '+ yPos + 'px';
				subpageHeaderBg.css({ backgroundPosition: coords });
			});
		};
	};

})(jQuery);
