/*
	Header Stuck
*/
(function($){
	var $topBar = $('#top-bar'),
		$window = $(window);

	var scroll = $window.scrollTop();
	if (scroll > 20){
		$topBar.addClass("stuck");
	};

	$window.on('scroll', function(){
		var scroll = $window.scrollTop();
		if (scroll > 20){
			$topBar.addClass("stuck");
		} else {
			$topBar.removeClass("stuck");
		};
	});
})(jQuery);
