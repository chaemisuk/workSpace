(function($){
	var jsScrollDown =  $('#js-scroll-down'),
		scrollDownAnchor = $('#scroll-down-anchor'),
		$window = $(window);

	if (jsScrollDown.length && scrollDownAnchor.length){
		initbacktotop();
	};
	function initbacktotop(){
		jsScrollDown.on('click', function(e){
			$('html, body').animate({
				scrollTop: scrollDownAnchor.offset().top
			}, 1000);
			return false;
		});
		$window.scroll(function(){
			$window.scrollTop() > 500 ? jsScrollDown.stop(true.false).addClass('show') : jsScrollDown.stop(true.false).removeClass('show');
		});
	};
})(jQuery);
