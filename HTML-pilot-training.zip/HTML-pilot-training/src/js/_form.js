/*
	Slick init
*/
(function($){
	var $formDefault = $('#mainContent .form-default .form-control:not(select)');
	if($formDefault.length){
	$formDefault.focus(function(){
		$(this).parents('.form-group').addClass('focused');
	});

	$formDefault.blur(function(){
		var inputValue = $(this).val();
		if (inputValue == ""){
			$(this).removeClass('filled');
			$(this).parents('.form-group').removeClass('focused');
		} else {
			$(this).addClass('filled');
		};
		});
	};
})(jQuery);
