/*
	Shop Slider Product
*/
(function($){
	var	sliderProduct = $('#mainContent .slider-product');
	if(sliderProduct.length){
		$('body').on('click', '.slider-product .img-small a', function(e){
			e.preventDefault();
			var imgLarge = $(this).closest('.slider-product').find('.img-large img');
			$(this).closest('.item').addClass('active').siblings().removeClass('active');
			imgLarge.hide().attr('src', $(this).attr('href'));
			imgLarge.fadeIn(300);
		});
	};
})(jQuery);
