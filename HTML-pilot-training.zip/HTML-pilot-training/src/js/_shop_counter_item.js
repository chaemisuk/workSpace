(function($){
	'use strict'

	var	$counterItem = $('#mainContent .js-counter-item');

	if(!$counterItem.length) return;

	$counterItem.on('click', '.minus-btn, .plus-btn', function(){
		var $this = $(this),
			$count = $this.siblings(".count"),
			delta = $this.hasClass('plus-btn') ? 1 : -1;
		$count.val(Math.max(0, parseInt($count.val()) + delta));
	});
})(jQuery);
