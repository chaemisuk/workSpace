/*
	Carusel Award
*/
(function($){
	var $sliderInit = $('#mainContent .js-award-carusel');
	if(!$sliderInit.length) return;
	$sliderInit.slick({
		dots: false,
		arrows: true,
		infinite: true,
		speed: 300,
		slidesToShow: 4,
		slidesToScroll: 1,
		adaptiveHeight: true,
		responsive: [
			{
				breakpoint: 790,
				settings: {
					slidesToShow: 3,
					slidesToScroll: 1,
				}
			},
			{
				breakpoint: 576,
				settings: {
					slidesToShow: 2,
					slidesToScroll: 1,
				}
			}
		]
	});
})(jQuery);
