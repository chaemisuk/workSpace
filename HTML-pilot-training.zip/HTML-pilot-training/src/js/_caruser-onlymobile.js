/*
	Slider External Block
*/
(function($){
	const init = {
	  autoplay: false,
	  infinite: false,
	  arrows:false,
	  cssEase: "linear",
	  slidesToShow: 1,
	  slidesToScroll: 1
	};
	$(() => {
	  const win = $(window);
	  const slider = $("#mainContent .js-mobile-slider");

	  win.on("load resize", () => {
	    if (win.width() < 790) {
	      slider.not(".slick-initialized").slick(init);
	    } else if (slider.hasClass("slick-initialized")) {
	      slider.slick("unslick");
	    }
	  });
	});
})(jQuery);

