(function($){
	var ptBackToTop = $('#js-back-to-top'),
		$window = $(window);

	if (ptBackToTop.length){
		ptBackToTop.on('click', function(e){
			$('html, body').animate({
				scrollTop: 0
			}, 500);
			return false;
		});
		$window.scroll(function(){
			$window.scrollTop() > 750 ? ptBackToTop.stop(true.false).addClass('show') : ptBackToTop.stop(true.false).removeClass('show');
		});
	};
})(jQuery);
