/*
	Gallery
*/
(function($){
	var $window = $(window),
	$ttPageContent = $('#mainContent'),
	gallery = $ttPageContent.find('.galley-masonry');

	$window.on('load', function(){
		var ttwindowWidth = window.innerWidth || $window.width();

		if (gallery.length){
			initGallery();
			initGalleyPopup();
		};
	});
	function initGallery(){
		var $grid = gallery.find('.tt-portfolio-content').isotope({
			itemSelector: '.element-item',
			layoutMode: 'masonry',
		});
		$grid.imagesLoaded().progress( function() {
			$grid.isotope('layout').addClass('tt-show');
		});
		var ttFilterNav =  gallery.find('.filter-nav');
		if (ttFilterNav.length) {
			var filterFns = {
				ium: function() {
					var name = $(this).find('.name').text();
					return name.match(/ium$/);
				}
			};
			ttFilterNav.on('click', '.button', function() {
				var filterValue = $(this).attr('data-filter');
				filterValue = filterFns[filterValue] || filterValue;
				$grid.isotope({
				  filter: filterValue
				});
				$(this).addClass('active').siblings().removeClass('active');
			});
		};
	};
	function initGalleyPopup() {
		var objZoom = $ttPageContent.find('.galley-masonry .btn-zomm');
		objZoom.magnificPopup({
			type: 'image',
			gallery: {
				enabled: true
			}
		});
	};
})(jQuery);
