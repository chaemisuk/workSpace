/*
	Promobox03 Hover
*/
(function($){
	var $object = $('#mainContent .promobox03');
	if ($object.length){
		$object.find('.promobox03__show').slideUp('0');
		$('body .promobox03').hover(
			function(){
				$(this).find('.promobox03__show').stop().delay(100).slideDown('200');
			},
			function(){
				$(this).find('.promobox03__show').stop().delay(100).slideUp().removeAttr("style");
			}
		);
	};
})(jQuery);
