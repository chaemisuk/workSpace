/*
	Slider External Block
*/
(function($){
	var $sliderInit =  $('#mainContent .wrapper-carusel-two-col .js-carusel-two-col'),
		$slickArrowExtraLeft = $(' #mainContent .wrapper-carusel-two-col .slick-arrow-extraleft'),
		$sliderArrowLeft = $slickArrowExtraLeft.find('.slick-prev'),
		$sliderArrowRight = $slickArrowExtraLeft.find('.slick-next');

	if(!$sliderInit.length) return;
	$sliderInit.slick({
		dots: false,
		arrows: false,
		infinite: true,
		speed: 300,
		slidesToShow: 3,
		slidesToScroll: 1,
		adaptiveHeight: true,
		responsive: [
			{
				breakpoint: 791,
				settings: {
					slidesToShow: 2,
					slidesToScroll: 1,
				}
			},
			{
				breakpoint: 576,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1,
				}
			}
		]
	});
	if ($sliderArrowRight.length && $sliderArrowLeft.length){
		$sliderArrowRight.on('click', function(){
			$sliderInit.slick('slickNext');
		});
		$sliderArrowLeft.on('click', function(){
			$sliderInit.slick('slickPrev');
		});
	};
})(jQuery);
