/*
	Form Init Select
*/
(function($){
	'use strict'
	var objSelect = $('#mainContent .js-init-select');
	if(!objSelect.length) return;
	objSelect.niceSelect();
})(jQuery);
