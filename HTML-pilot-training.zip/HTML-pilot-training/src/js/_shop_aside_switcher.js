(function($){
	'use strict'

	var	$colorSwitcher = $('#mainContent .js-color-switcher');

	if(!$colorSwitcher) return;

	(function switcherList(){
		$colorSwitcher.find('li').on('click', this, function(e){
			$(this).addClass('active').siblings().removeClass('active');
			return false;
		});
	})();
})(jQuery);
