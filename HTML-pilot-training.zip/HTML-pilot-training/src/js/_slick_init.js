/*
	Slick init
*/
(function($){
	$('#mainContent [data-slick]').each(function(index, element){
		if($(element).hasClass('slick-initialized')) return;
		$(element).slick();
	});
	var $jsCaruselTwoCol = $('#mainContent .js-carusel-two-col');
	if($jsCaruselTwoCol.length) return;
	$jsCaruselTwoCol.slick({
		dots: false,
		infinite: true,
		speed: 300,
		slidesToShow: 3,
		slidesToScroll: 1,
		adaptiveHeight: true
	});
})(jQuery);
