/*
	Carusel Partners
*/
(function($){
	var $sliderInit =  $('#mainContent .js-presentation-projects'),
		$slickArrowExtraLeft = $(' #mainContent .presentation-projects .slick-slick-arrow'),
		$sliderArrowLeft = $slickArrowExtraLeft.find('.slick-prev'),
		$sliderArrowRight = $slickArrowExtraLeft.find('.slick-next');

	if(!$sliderInit.length) return;

	$sliderInit.slick({
		dots: false,
		arrows: false,
		infinite: true,
		speed: 300,
		fade: true,
		slidesToShow: 1,
		slidesToScroll: 1,
		adaptiveHeight: true
	});
	function contentСentering(){
		setTimeout(function(){
			var $imgHeight = $sliderInit.find('picture img').height();
			$('.col-link-wrapper').height($imgHeight);
		}, 310);
	};
	contentСentering();
	$(window).resize(function(e){
		contentСentering();
	});
	if ($sliderArrowRight.length && $sliderArrowLeft.length){
		$sliderArrowRight.on('click', function(){
			$sliderInit.slick('slickNext');
		});
		$sliderArrowLeft.on('click', function(){
			$sliderInit.slick('slickPrev');
		});
	};
})(jQuery);
