/*
	AOS init
*/
AOS.init({
	offset: 100,
	duration: 900,
	easing: 'ease-out',
	delay: 100,
	once: true,
	disable: 'mobile'
});

