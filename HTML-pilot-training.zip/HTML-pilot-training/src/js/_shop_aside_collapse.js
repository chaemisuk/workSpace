(function($){
	'use strict'

	var	$colAside = $('#js-aside-col'),
		$collapseAside = $colAside.find('.collapse-aside .collapse-aside__title');

	if(!$colAside && !$collapseAside) return;

	(function toggleColAside(){
		$collapseAside.on('click', this, function(e){
			var ptlayout = $(this).next();

			$(this).toggleClass('is-open');
			if(ptlayout.css('display') == 'none'){
				ptlayout.slideToggle(200);
			} else if(ptlayout.css('display') == 'block'){
				ptlayout.slideToggle(200);
			};
		});
	})();
})(jQuery);
