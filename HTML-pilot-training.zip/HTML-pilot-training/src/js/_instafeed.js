(function($){
	$.fn.instafeed = function(new_object){
		var $this = $(this),
			$accessToken = $(this).attr('data-accessToken'),
			$clientId = $(this).attr('data-clientId'),
			$userId = $(this).attr('data-userId'),
			$limitImg = $(this).attr('data-limitImg');

		if(!$this.length) return;
		var new_object = new_object || {},
			set_object = {
			get: 'user',
			userId: $userId,
			clientId: $clientId,
			limit: $limitImg,
			sortBy: 'most-liked',
			resolution: "standard_resolution",
			accessToken: $accessToken,
			template: '<a href="{{link}}" target="_blank"><img src="{{image}}" /></a>',
		};
		$.extend(set_object, new_object);
		var feed = new Instafeed(set_object);
		feed.run();
	};
	$('#instafeed').each(function(){
		$(this).instafeed();
	});
})(jQuery);
