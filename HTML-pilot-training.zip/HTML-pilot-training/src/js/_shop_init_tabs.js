/*
	Tabs Default
*/
(function($){
	var $navTabs = $('#mainContent .nav-tabs');
	if ($navTabs.length){
		$('body').on('click', '#mainContent .nav-tabs', function(e){
			e.preventDefault();
			$(this).tab('show');
		});
	};
})(jQuery);
