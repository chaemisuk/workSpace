/*
	Navigation Toggler
*/
(function($){
	var btnToggle = $('#top-bar__navigation-toggler');
	if(btnToggle.length){
		var $html = $('html'),
			$body = $('body'),
			$navigationAside = $('#nav-aside'),
			$btnClose = $navigationAside.find('.nav-aside__close');

		btnToggle.on('click', function(e){
			e.preventDefault();
			var ttScrollValue = $body.scrollTop() || $html.scrollTop();
			$navigationAside.toggleClass('aside-open').perfectScrollbar();
			$body.css("top", - ttScrollValue).addClass("no-scroll").append('<div class="nav-aside-background"></div>');
			var modalFilter = $('.nav-aside-background').fadeTo('fast',1);
			if (modalFilter.length){
				modalFilter.on('click', function(){
					$btnClose.trigger('click');
				})
			}
			return false;
		});
		$btnClose.on('click', function(e){
			e.preventDefault();
			$navigationAside.removeClass('aside-open').perfectScrollbar('destroy');
			var top = parseInt($body.css("top").replace("px", ""), 10) * -1;
			$body.removeAttr("style").removeClass("no-scroll").scrollTop(top);
			$html.removeAttr("style").scrollTop(top);
			$(".nav-aside-background").off().remove();
		});
	}
})(jQuery);
