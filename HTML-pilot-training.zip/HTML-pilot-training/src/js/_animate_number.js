/*
	Animation Number
*/
(function($){
	var time = 1,
		cc = 1,
		$mainContent = $('#mainContent'),
		$section = $mainContent.find('.section');

	$(window).on('scroll', function(){
		$section.each(function(){
			var cPos = $(this).offset().top,
				topWindow = $(window).scrollTop();
			if(cPos < topWindow + 300){
				if(cc < 2){
					$('.animate-number').addClass("viz").each(function(){
						var
						i = 1,
						num = $(this).data('num'),
						step = 500 * time / num,
						that = $(this),
						int = setInterval(function(){
						if (i <= num) {
							that.html(i);
						}
						else {
							cc= cc+2;
							clearInterval(int);
						}
						i++;
						},step);
					});
				}
			}
		});
	});
})(jQuery);
