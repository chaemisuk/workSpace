/*
	Carusel Blockquote
*/
(function($){
	var $sliderInit =  $('#mainContent .js-carusel-blockquote'),
		$slickArrow = $sliderInit.closest('section').find('.slick-arrow-external'),
		$sliderArrowLeft = $slickArrow.find('.slick-prev'),
		$sliderArrowRight = $slickArrow.find('.slick-next');

	if(!$sliderInit.length) return;

	$sliderInit.slick({
		dots: false,
		arrows: false,
		infinite: true,
		speed: 300,
		slidesToShow: 1,
		slidesToScroll: 1,
		adaptiveHeight: true
	});
	if ($sliderArrowRight.length){
		$sliderArrowRight.on('click', function(e){
			$sliderInit.slick('slickNext');
			return false;
		});
	};
	if ($sliderArrowLeft.length){
		$sliderArrowLeft.on('click', function(e){
			$sliderInit.slick('slickPrev');
			return false;
		});
	};
})(jQuery);
