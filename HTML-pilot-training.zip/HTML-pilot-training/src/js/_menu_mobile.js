/*
	Mobile Menu
*/
(function($){
	var $mobileMenu = $('#nav-aside_menu'),
		$topBarNavigation = $('#top-bar__navigation > ul');

	if(!$mobileMenu && !$topBarNavigation) return;

	var $objBarNavigation = $topBarNavigation.clone();
	$mobileMenu.append($objBarNavigation);
	$mobileMenu.find('li').each(function(){
		if($(this).is(':has(ul)')){
			$(this).addClass('is-submenu');
		}
	});
	$(document).on('click', '#nav-aside_menu li.is-submenu > a', function(e){
		$(this).parent('#nav-aside_menu li.is-submenu').toggleClass('is-open');
		return false;
	});
})(jQuery);
