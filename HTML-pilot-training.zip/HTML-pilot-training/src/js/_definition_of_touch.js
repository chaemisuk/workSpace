/*
	Definition of touch devices
*/
(function($){
	function isTouchDevice(){
		return typeof window.ontouchstart !== 'undefined';
	};
	if(isTouchDevice()){
		$('body').addClass('touch').one('click', '#mainContent .block-once', function(event){
			event.preventDefault();
		});
	};
})(jQuery);
