(function($){
	var	$body = $('body'),
		$html = $('html'),
		$colAside = $('#js-aside-col'),
		$btnToggleAside = $('#js-toggle-aside');

	if(!$colAside && !$btnToggleAside) return;

	(function toggleColAside(){
		var $btnCloseAside = $colAside.find('.btn-asidecol-close');
		$btnToggleAside.on('click', function(e){
			e.preventDefault();
			var ptScrollValue = $body.scrollTop() || $html.scrollTop();
			$colAside.toggleClass('is-open').perfectScrollbar();
			$body.css("top", - ptScrollValue).addClass("no-scroll").append('<div class="filter-bg"></div>');
			var modalFilter = $('.filter-bg').fadeTo('fast',1);
			if (modalFilter.length){
				modalFilter.on('click', function(){
					$btnCloseAside.trigger('click');
				})
			}
			return false;
		});
		$btnCloseAside.on('click', function(e){
			e.preventDefault();
			$colAside.removeClass('is-open').perfectScrollbar('destroy');
			var top = parseInt($body.css("top").replace("px", ""), 10) * -1;
			$body.removeAttr("style").removeClass("no-scroll").scrollTop(top);
			$html.removeAttr("style").scrollTop(top);
			$(".filter-bg").off().remove();
		});
	})();
})(jQuery);
