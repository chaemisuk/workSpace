(function($){
	var methods = {
		init: function(options){
			return this.each(function(){
				var $this = $(this);
				methods.alignmen(options, $this);
			});
		},
		alignmen: function(options, $this){
			var arrow = $this.find('.slick-arrow'),
				arrowHeight = arrow.findHeight(),
				obj = $this.find('.' + options.centeringObject),
				objHeight = obj.findHeight();

			arrow.css({
				'top' : objHeight - arrowHeight,
				'margin-top': '0px'
			}).animate({opacity: 1});
		}
	};
	$.fn.alignment = function(action){
		if(methods[action]){
			return methods[action].apply(this, Array.prototype.slice.call(arguments, 1));
		} else if(typeof action === 'object' || !action){
			return methods.init.apply(this, arguments);
		} else {
			console.info('Action ' +action+ 'not found this plugin');
			return this;
		}
	};
	$.fn.findHeight = function(){
		var $box = $(this),
			maxH = $box.eq(0).innerHeight();

		$box.each(function(){
			maxH = ( $(this).innerHeight() > maxH ) ? $(this).innerHeight() : maxH;
		});

		return maxH/2;
	};
	$(window).resize((function(e){
		setTimeout(function(){
			$('#mainContent .js-align-arrow-award').imagesLoaded().alignment({
				centeringObject: 'award__img'
			});
		}, 500);
	})).resize();
	function debouncer(func, timeout) {
		var timeoutID, timeout = timeout || 500;
		return function() {
			var scope = this,
				args = arguments;
			clearTimeout(timeoutID);
			timeoutID = setTimeout(function(){
				func.apply(scope, Array.prototype.slice.call(args));
			}, timeout);
		}
	};
})(jQuery);
