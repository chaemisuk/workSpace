/*
	Slider External Block
*/
(function($){
	var $sliderInit =  $('#mainContent .js-carusel-external-box'),
		$sliderArrow = $('#mainContent .layout-external-box .col-nav-slider');

	if(!$sliderInit.length) return;
	$sliderInit.slick({
		infinite: true,
		slidesToShow: 1,
		slidesToScroll: 1,
		arrows: false
	});
	if ($sliderArrow.length){
		$sliderArrow.on('click', function(){
			$sliderInit.slick('slickNext');
		});
	};
})(jQuery);
