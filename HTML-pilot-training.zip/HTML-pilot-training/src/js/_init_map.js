(function ($){

	function map() {

		var map = $('#mainContent .googlemap');

		if (map.length > 0){

			var apiKey = map.attr('data-api-key'),
				apiURL;

			if (apiKey) {
				apiURL = 'https://maps.google.com/maps/api/js?key='+ apiKey +' &sensor=false';	
			} 
			
			else {
				apiURL = 'https://maps.google.com/maps/api/js?sensor=false';
			};

			$.getScript( apiURL , function(data, textStatus, jqxhr){
				map.each(function(){

					var current_map = $(this),

						latlng = new google.maps.LatLng(current_map.attr('data-longitude'),

						current_map.attr('data-latitude')),

						point = current_map.attr('data-marker'),

						center = {
							lat: 40.730610,
							lng: -73.935242,
						},

						markerPos = {
							lat: 40.730610,
							lng: -73.935242,
						},

						myOptions = {
							zoom: 14,
							center: center,
							disableDefaultUI: true,
							mapTypeId: google.maps.MapTypeId.ROADMAP,
							mapTypeControl: false,
							scrollwheel: false,
							draggable: true,
							panControl: false,
							zoomControl: false,
							disableDefaultUI: true,
							styles: [
								{
									"featureType": "administrative",
									"elementType": "labels.text.fill",
									"stylers": [
										{
											"color": "#212326"
										}
									]
								},
								{
									"featureType": "administrative.locality",
									"elementType": "labels.text.fill",
									"stylers": [
										{
											"color": "#464646"
										}
									]
								},
								{
									"featureType": "landscape",
									"elementType": "all",
									"stylers": [
										{
											"color": "#F8F8F9"
										}
									]
								},
								{
									"featureType": "poi",
									"elementType": "all",
									"stylers": [
										{
											"visibility": "off"
										}
									]
								},
								{
									"featureType": "road",
									"elementType": "all",
									"stylers": [
										{
											"saturation": -100
										},
										{
											"lightness": 45
										}
									]
								},
								{
									"featureType": "road",
									"elementType": "labels",
									"stylers": [
										{
											"visibility": "on"
										}
									]
								},
								{
									"featureType": "road",
									"elementType": "labels.icon",
									"stylers": [
										{
											"visibility": "on"
										}
									]
								},
								{
									"featureType": "transit",
									"elementType": "all",
									"stylers": [
										{
											"visibility": "on"
										}
									]
								},
								{
									"featureType": "road.highway",
									"elementType": "all",
									"stylers": [
										{
											"visibility": "on"
										}
									]
								},
								{
									"featureType": "road.arterial",
									"elementType": "labels.icon",
									"stylers": [
										{
											"visibility": "on"
										}
									]
								},
								{
									"featureType": "transit",
									"elementType": "all",
									"stylers": [
										{
											"visibility": "on"
										}
									]
								},
								{
									"featureType": "water",
									"elementType": "all",
									"stylers": [
										{
											"color": "#E2E3E7"
										},
										{
											"visibility": "on"
										}
									]
								}
							]
						};

					var map = new google.maps.Map(current_map[0], myOptions);

					var marker = new google.maps.Marker({
						map: map,
						icon: {
							size: new google.maps.Size(59,69),
							origin: new google.maps.Point(0,0),
							anchor: new google.maps.Point(0,69),
							url: point
						},
						position: markerPos
					});

					google.maps.event.addDomListener(window, "resize", function(){
						var center = map.getCenter();
						google.maps.event.trigger(map, "resize");
						map.setCenter(center);
					});
				});
			});
		};
	}	

	map();

})(jQuery);