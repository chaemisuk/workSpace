/*
	Slider Price (shop aside)
*/
(function($){
	var $priceSlider = $('#price-slider');
	if ($priceSlider.length){
		$priceSlider.find('.nstSlider').nstSlider({
			"left_grip_selector": ".leftGrip",
			"right_grip_selector": ".rightGrip",
			"value_bar_selector": ".bar",
			"value_changed_callback": function(cause, leftValue, rightValue) {
				$(this).parent().find('.leftLabel').text(leftValue);
				$(this).parent().find('.rightLabel').text(rightValue);
			}
		});
	};
})(jQuery);
