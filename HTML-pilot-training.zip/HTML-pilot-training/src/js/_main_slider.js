/*
	Main Slider
*/
(function($){
	dataBg('[data-bg]');
	function dataBg(el){
		$(el).each(function(){
			var $this = $(this),
					bg = $this.attr('data-bg');
			$this.css({
				'background-image': 'url(' + bg + ')'
			});
		});
	};
	var mainSlider = $('.mainSlider');
	if (mainSlider.length){
		mainslider();
	};
	function mainslider(){
		var $obj = mainSlider;
		$obj.find('.slide').first().imagesLoaded({
			background: true
		}, function(){
			setTimeout(function(){
				$obj.parent().find('.loading-content').addClass('disable');
			}, 100);
		});
		$obj.on('init', function (e, slick){
			var $firstAnimatingElements = $('div.slide:first-child').find('[data-animation]');
			runAnimation($firstAnimatingElements);
		});
		$obj.on('beforeChange', function (e, slick, currentSlide, nextSlide){
			var $currentSlide = $('div.slide[data-slick-index="' + nextSlide + '"]');
			var $animatingElements = $currentSlide.find('[data-animation]');
			runAnimation($animatingElements);
		});
		var dataArrow = $obj.data('arrow'),
			dataDots = $obj.data('dots');
		$obj.slick({
			arrows: dataArrow || false,
			dots: dataDots || false,
			autoplay: true,
			autoplaySpeed: 5500,
			fade: true,
			speed: 1000,
			pauseOnHover: false,
			pauseOnDotsHover: true,
			customPaging: function (slider, i) {
				return '<span>' + '0' + (i + 1) + '</span>';
			}
		});
	};
	function runAnimation(elements){
		var animationEndEvents = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';
		elements.each(function(){
			var $this = $(this),
					$animationType = 'animated ' + $this.data('animation'),
					$animationDelay = $this.data('animation-delay');
			$this.css({
				'animation-delay': $animationDelay,
				'-webkit-animation-delay': $animationDelay
			});
			$this.addClass($animationType).one(animationEndEvents, function(){
				$this.removeClass($animationType);
			});
			if ($this.hasClass('animate')){
				$this.removeClass('animation');
			}
		});
	};


	    var $allVideos = $("iframe[src^='//player.vimeo.com'], iframe[src^='//www.youtube.com'], object, embed"),
	    $fluidEl = $("figure");

		$allVideos.each(function() {

		  $(this)
		    // jQuery .data does not work on object/embed elements
		    .attr('data-aspectRatio', this.height / this.width)
		    .removeAttr('height')
		    .removeAttr('width');

		});

		$(window).resize(function() {

		  var newWidth = $fluidEl.width();
		  $allVideos.each(function() {

		    var $el = $(this);
		    $el
		        .width(newWidth)
		        .height(newWidth * $el.attr('data-aspectRatio'));

		  });

		}).resize();


})(jQuery);
