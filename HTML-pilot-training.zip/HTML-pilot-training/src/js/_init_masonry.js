/*
	Masonry
*/
(function($){
	var $mainContent = $('#mainContent'),
		masonryLayout01 = $mainContent.find('.masonry-layout-01'),
		$window = $(window),
		$body = $('body'),
		$html = $('html');

	$window.on('load', function(){
		var ptwindowWidth = window.innerWidth || $window.width();
		if (masonryLayout01.length){
			masonry();
		};
	});

	function masonry(){
		var $grid = masonryLayout01.find('.masonry-layout-01-init').isotope({
			itemSelector: '.element-item',
			layoutMode: 'masonry',
		});
		$grid.imagesLoaded().progress(function(){
			$grid.isotope('layout').addClass('pt-show');
		});
	};
})(jQuery);
