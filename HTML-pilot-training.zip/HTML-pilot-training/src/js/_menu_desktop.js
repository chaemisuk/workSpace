/*
	Desktop Menu
*/
(function($){
	var location = window.location.href,
		$desctopMenu = $('#top-bar__navigation');

	if(!$desctopMenu) return;

	$desctopMenu.find('li').each(function(){
		var link = $(this).find('a').attr('href');

		if(location.indexOf(link) !== -1){
			$(this).addClass('active').closest('.is-submenu').addClass('active');
		}
		if($(this).is(':has(ul)')){
			$(this).addClass('is-submenu');
		}
	});

	$desctopMenu.find('ul li').on("mouseenter", function(){
		var $ul = $(this).find('ul:first');
		$(this).find('a:first').addClass('is-hover');
		if ($ul.length){
			var windW = window.innerWidth,
				ulW = parseInt($ul.css('width'), 10) + 20,
				thisR = this.getBoundingClientRect().right,
				thisL = this.getBoundingClientRect().left;

			if (windW - thisR < ulW){
				$ul.addClass('right-popup');
			} else if (thisL < ulW){
				$ul.removeClass('right-popup');
			};
		}
	}).on('mouseleave', function(){
		$(this).find('a:first').removeClass('is-hover');
	});
})(jQuery);
