/*
	Slider External Block
*/
(function($){
	var $sliderInit = $('#mainContent .js-caruser-custom');
	if(!$sliderInit.length) return;
	$sliderInit.slick({
		dots: true,
		arrows: false,
		infinite: true,
		speed: 300,
		slidesToShow: 2,
		slidesToScroll: 1,
		adaptiveHeight: true,
		customPaging: function (slider, i) {
			return '<span>' + '0' + (i + 1) + '</span>';
		},
		responsive: [
			{
				breakpoint: 576,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1,
				}
			}
		]
	});
})(jQuery);
