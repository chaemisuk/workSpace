/*
	Carusel News
*/
(function($){
	var $sliderInit =  $('#mainContent .js-carusel-news'),
		$slickArrow = $sliderInit.closest('section').find('.slick-arrow-extraright'),
		$sliderArrowLeft = $slickArrow.find('.slick-prev'),
		$sliderArrowRight = $slickArrow.find('.slick-next');

	if(!$sliderInit.length) return;

	$sliderInit.slick({
		dots: false,
		arrows: false,
		infinite: true,
		speed: 300,
		slidesToShow: 3,
		slidesToScroll: 1,
		adaptiveHeight: true,
		responsive: [
			{
				breakpoint: 790,
				settings: {
					slidesToShow: 2,
					slidesToScroll: 1,
				}
			},
			{
				breakpoint: 576,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1,
				}
			}
		]
	});
	if ($sliderArrowRight.length && $sliderArrowLeft.length){
		$sliderArrowRight.on('click', function(e){
			$sliderInit.slick('slickNext');
			return false;
		});
		$sliderArrowLeft.on('click', function(e){
			$sliderInit.slick('slickPrev');
			return false;
		});
	};
})(jQuery);
