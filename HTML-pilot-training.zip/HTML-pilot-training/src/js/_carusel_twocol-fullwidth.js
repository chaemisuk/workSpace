/*
	Carusel Partners
*/
(function($){
	var $sliderInit =  $('#mainContent .js-carusel-twocol-fullwidth'),
		$slickArrowExtraLeft = $(' #mainContent .wrapper-carusel-partners .slick-slick-arrow'),
		$sliderArrowLeft = $slickArrowExtraLeft.find('.slick-prev'),
		$sliderArrowRight = $slickArrowExtraLeft.find('.slick-next');

	if(!$sliderInit.length) return;

	$sliderInit.slick({
		dots: false,
		arrows: false,
		infinite: true,
		speed: 300,
		slidesToShow: 3,
		slidesToScroll: 1,
		adaptiveHeight: true,
		responsive: [
			{
				breakpoint: 1024,
				settings: {
					slidesToShow: 2
				}
			},
			{
				breakpoint: 576,
				settings: {
					slidesToShow: 1
				}
			}
		]
	});
	if ($sliderArrowRight.length && $sliderArrowLeft.length){
		$sliderArrowRight.on('click', function(){
			$sliderInit.slick('slickNext');
		});
		$sliderArrowLeft.on('click', function(){
			$sliderInit.slick('slickPrev');
		});
	};
})(jQuery);
