(function($){
	'use strict'

	var	$colorSwitcher = $('#mainContent .menu-aside li');

	if(!$colorSwitcher) return;

	(function asideMenu(){
		$colorSwitcher.on('click', this, function(e){
			$(this).addClass('active').siblings().removeClass('active');
			return false;
		});
	})();
})(jQuery);
