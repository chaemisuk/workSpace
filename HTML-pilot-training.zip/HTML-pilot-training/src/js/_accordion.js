/*
	Accordeon
*/
(function($){
	var methods = {
		init: function(options){
			return this.each(function(){
				var object = $(this),
				objectOpen = object.find('.accordeon__item.is-open'),
				objectItemTitle = object.find('.accordeon__item .accordeon__title');

				objectOpen.find('.accordeon__content').slideToggle(100);

				objectItemTitle.on('click', function(){
					$(this).next().slideToggle(200).parent().toggleClass('is-open');
				});
			});
		}
	};
	$.fn.accordeon = function(action){
		if(methods[action]){
			return methods[action].apply(this, Array.prototype.slice.call(arguments, 1));
		} else if(typeof action === 'object' || !action){
			return methods.init.apply(this, arguments);
		} else {
			console.info('Action ' +action+ 'not found this plugin');
			return this;
		}
	};
	var jsAccordeon = $('#mainContent .js-accordeon');
	if(!jsAccordeon.length) return;
	jsAccordeon.accordeon();
})(jQuery);
