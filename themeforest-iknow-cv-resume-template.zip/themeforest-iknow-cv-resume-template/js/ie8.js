jQuery(document).ready(function(e) {
    jQuery('body').html('<div class="ie8"><span>Hi! Please, use the latest version of the browser in order to visit current page</span></div>')
});